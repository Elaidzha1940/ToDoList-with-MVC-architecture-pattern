//
//  Typealias.swift
//  BeautyApp
//
//  Created by Егор Бойко on 13.10.2022.
//



//MARK: Представления
typealias RSMain = MainRepresentation
//MARK: Компоненты

//MARK: Модули
