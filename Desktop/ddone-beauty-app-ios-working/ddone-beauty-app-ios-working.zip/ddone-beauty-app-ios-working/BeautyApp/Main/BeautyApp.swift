//
//  BeautyApp.swift
//  BeautyApp
//
//  Created by Егор Бойко on 13.10.2022.
//

import SwiftUI

@main
struct BeautyApp: App {
    var body: some Scene {
        WindowGroup {
            RSMain()
        }
    }
}
