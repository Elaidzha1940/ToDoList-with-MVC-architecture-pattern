//
//  MainRepresentation.swift
//  BeautyApp
//
//  Created by Егор Бойко on 13.10.2022.
//

import Foundation

import SwiftUI

internal struct MainRepresentation: View {
    internal var body: some View {
        VStack {
            
            Rectangle()
                .foregroundColor(.background)
            Text("BeautyApp")
        }
        .background(Color.background(.scheme))
        .padding()
        .preferredColorScheme(.dark)
    }
}


struct MainRepresentation_Previews: PreviewProvider {
    static var previews: some View {
        MainRepresentation()
    }
}
